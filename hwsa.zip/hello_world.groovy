print "Hello World!\n"
